module src {
	requires java.desktop;
	requires java.sql;
	requires java.rmi;
}